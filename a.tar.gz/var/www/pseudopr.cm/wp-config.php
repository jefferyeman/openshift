<?php



// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'pseudopr_cm');

/** MySQL database username */
define('DB_USER', 'pseudopr_cm');

/** MySQL database password */
define('DB_PASSWORD', 'cCWDEjoGhOuT61V');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         'jXm7l~]vt}f)jNUym^A$RYSChM}nl+18lD7|I/>r9sDw,:&P402a3WoW 8zBHd4@');
define('SECURE_AUTH_KEY',  ' ep|!wI0Xl67F?*O2nah>8i8{|,N^d+<g6|/5tY$%_w4Nw><l:U0lL,?gvJxi0I+');
define('LOGGED_IN_KEY',    '*{`{%x!FLp,Hj6E(KMU>.C0oWoPM=SBSU1*93Oya57jNpY1bi%?#OViga+AJYOA(');
define('NONCE_KEY',        'S}q`u kl{)|vqd]B+k)gnqaf3fO2J,#sGrbRfl5Rl7?wX|.,uMTK|b#! #m^?t*@');
define('AUTH_SALT',        'Llz%_j98Tr(y11?v0},m92Ns)}ntmOxV<Xn+8lVCF=(&Wgh5 pQC#b43xLj;+i:6');
define('SECURE_AUTH_SALT', '{o1p$3vR2p#E[i!4t (T|w{-rHe9y4S>2kwZlYb=-nkVp9b!y E:.x3e=I6!y)p<');
define('LOGGED_IN_SALT',   '-=i`|&>/t4u`jre`vQ,c/O)]?%N$%2~A@+7;c+QqXAP<70*` &`cXfH7,[++3(d+');
define('NONCE_SALT',       'g]?>](xSC lJggbvkL-rp]+~]rkmXDQg_f?6<cC%$]uUmk{i4PYV~yA`-^5R$?6c');


$table_prefix = 'wp_';


 

define('WP_DEBUG', false); 



/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
